# AWS EC2 Web Server Deployment Project

## Overview

This project demonstrates deployment of a static website on AWS EC2
using Ubuntu and Nginx.

## Steps

1.  Launch EC2 instance
2.  SSH into server
3.  Install Nginx
4.  Deploy website
5.  Configure monitoring

## Screenshots

(Add your screenshots here)
